# ===================================================================================================
#                           _  __     _ _
#                          | |/ /__ _| | |_ _  _ _ _ __ _
#                          | ' </ _` | |  _| || | '_/ _` |
#                          |_|\_\__,_|_|\__|\_,_|_| \__,_|
#
# This file is part of the Kaltura Collaborative Media Suite which allows users
# to do with audio, video, and animation what Wiki platfroms allow them to do with
# text.
#
# Copyright (C) 2006-2011  Kaltura Inc.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http:#www.gnu.org/licenses/>.
#
# @ignore
# ===================================================================================================
# @package Kaltura
# @subpackage Client
from Core import *
from DropFolder import *
from ..Base import *

########## enums ##########
########## classes ##########
# @package Kaltura
# @subpackage Client
class KalturaWebexDropFolder(KalturaDropFolder):
    def __init__(self,
            id=NotImplemented,
            partnerId=NotImplemented,
            name=NotImplemented,
            description=NotImplemented,
            type=NotImplemented,
            status=NotImplemented,
            conversionProfileId=NotImplemented,
            dc=NotImplemented,
            path=NotImplemented,
            fileSizeCheckInterval=NotImplemented,
            fileDeletePolicy=NotImplemented,
            autoFileDeleteDays=NotImplemented,
            fileHandlerType=NotImplemented,
            fileNamePatterns=NotImplemented,
            fileHandlerConfig=NotImplemented,
            tags=NotImplemented,
            errorCode=NotImplemented,
            errorDescription=NotImplemented,
            ignoreFileNamePatterns=NotImplemented,
            createdAt=NotImplemented,
            updatedAt=NotImplemented,
            lastAccessedAt=NotImplemented,
            incremental=NotImplemented,
            lastFileTimestamp=NotImplemented,
            metadataProfileId=NotImplemented,
            categoriesMetadataFieldName=NotImplemented,
            enforceEntitlement=NotImplemented,
            webexUserId=NotImplemented,
            webexPassword=NotImplemented,
            webexSiteId=NotImplemented,
            webexPartnerId=NotImplemented,
            webexServiceUrl=NotImplemented,
            webexHostIdMetadataFieldName=NotImplemented):
        KalturaDropFolder.__init__(self,
            id,
            partnerId,
            name,
            description,
            type,
            status,
            conversionProfileId,
            dc,
            path,
            fileSizeCheckInterval,
            fileDeletePolicy,
            autoFileDeleteDays,
            fileHandlerType,
            fileNamePatterns,
            fileHandlerConfig,
            tags,
            errorCode,
            errorDescription,
            ignoreFileNamePatterns,
            createdAt,
            updatedAt,
            lastAccessedAt,
            incremental,
            lastFileTimestamp,
            metadataProfileId,
            categoriesMetadataFieldName,
            enforceEntitlement)

        # @var string
        self.webexUserId = webexUserId

        # @var string
        self.webexPassword = webexPassword

        # @var int
        self.webexSiteId = webexSiteId

        # @var string
        self.webexPartnerId = webexPartnerId

        # @var string
        self.webexServiceUrl = webexServiceUrl

        # @var string
        self.webexHostIdMetadataFieldName = webexHostIdMetadataFieldName


    PROPERTY_LOADERS = {
        'webexUserId': getXmlNodeText, 
        'webexPassword': getXmlNodeText, 
        'webexSiteId': getXmlNodeInt, 
        'webexPartnerId': getXmlNodeText, 
        'webexServiceUrl': getXmlNodeText, 
        'webexHostIdMetadataFieldName': getXmlNodeText, 
    }

    def fromXml(self, node):
        KalturaDropFolder.fromXml(self, node)
        self.fromXmlImpl(node, KalturaWebexDropFolder.PROPERTY_LOADERS)

    def toParams(self):
        kparams = KalturaDropFolder.toParams(self)
        kparams.put("objectType", "KalturaWebexDropFolder")
        kparams.addStringIfDefined("webexUserId", self.webexUserId)
        kparams.addStringIfDefined("webexPassword", self.webexPassword)
        kparams.addIntIfDefined("webexSiteId", self.webexSiteId)
        kparams.addStringIfDefined("webexPartnerId", self.webexPartnerId)
        kparams.addStringIfDefined("webexServiceUrl", self.webexServiceUrl)
        kparams.addStringIfDefined("webexHostIdMetadataFieldName", self.webexHostIdMetadataFieldName)
        return kparams

    def getWebexUserId(self):
        return self.webexUserId

    def setWebexUserId(self, newWebexUserId):
        self.webexUserId = newWebexUserId

    def getWebexPassword(self):
        return self.webexPassword

    def setWebexPassword(self, newWebexPassword):
        self.webexPassword = newWebexPassword

    def getWebexSiteId(self):
        return self.webexSiteId

    def setWebexSiteId(self, newWebexSiteId):
        self.webexSiteId = newWebexSiteId

    def getWebexPartnerId(self):
        return self.webexPartnerId

    def setWebexPartnerId(self, newWebexPartnerId):
        self.webexPartnerId = newWebexPartnerId

    def getWebexServiceUrl(self):
        return self.webexServiceUrl

    def setWebexServiceUrl(self, newWebexServiceUrl):
        self.webexServiceUrl = newWebexServiceUrl

    def getWebexHostIdMetadataFieldName(self):
        return self.webexHostIdMetadataFieldName

    def setWebexHostIdMetadataFieldName(self, newWebexHostIdMetadataFieldName):
        self.webexHostIdMetadataFieldName = newWebexHostIdMetadataFieldName


# @package Kaltura
# @subpackage Client
class KalturaWebexDropFolderFile(KalturaDropFolderFile):
    def __init__(self,
            id=NotImplemented,
            partnerId=NotImplemented,
            dropFolderId=NotImplemented,
            fileName=NotImplemented,
            fileSize=NotImplemented,
            fileSizeLastSetAt=NotImplemented,
            status=NotImplemented,
            type=NotImplemented,
            parsedSlug=NotImplemented,
            parsedFlavor=NotImplemented,
            parsedUserId=NotImplemented,
            leadDropFolderFileId=NotImplemented,
            deletedDropFolderFileId=NotImplemented,
            entryId=NotImplemented,
            errorCode=NotImplemented,
            errorDescription=NotImplemented,
            lastModificationTime=NotImplemented,
            createdAt=NotImplemented,
            updatedAt=NotImplemented,
            uploadStartDetectedAt=NotImplemented,
            uploadEndDetectedAt=NotImplemented,
            importStartedAt=NotImplemented,
            importEndedAt=NotImplemented,
            batchJobId=NotImplemented,
            recordingId=NotImplemented,
            webexHostId=NotImplemented,
            description=NotImplemented,
            confId=NotImplemented,
            contentUrl=NotImplemented):
        KalturaDropFolderFile.__init__(self,
            id,
            partnerId,
            dropFolderId,
            fileName,
            fileSize,
            fileSizeLastSetAt,
            status,
            type,
            parsedSlug,
            parsedFlavor,
            parsedUserId,
            leadDropFolderFileId,
            deletedDropFolderFileId,
            entryId,
            errorCode,
            errorDescription,
            lastModificationTime,
            createdAt,
            updatedAt,
            uploadStartDetectedAt,
            uploadEndDetectedAt,
            importStartedAt,
            importEndedAt,
            batchJobId)

        # @var int
        self.recordingId = recordingId

        # @var string
        self.webexHostId = webexHostId

        # @var string
        self.description = description

        # @var string
        self.confId = confId

        # @var string
        self.contentUrl = contentUrl


    PROPERTY_LOADERS = {
        'recordingId': getXmlNodeInt, 
        'webexHostId': getXmlNodeText, 
        'description': getXmlNodeText, 
        'confId': getXmlNodeText, 
        'contentUrl': getXmlNodeText, 
    }

    def fromXml(self, node):
        KalturaDropFolderFile.fromXml(self, node)
        self.fromXmlImpl(node, KalturaWebexDropFolderFile.PROPERTY_LOADERS)

    def toParams(self):
        kparams = KalturaDropFolderFile.toParams(self)
        kparams.put("objectType", "KalturaWebexDropFolderFile")
        kparams.addIntIfDefined("recordingId", self.recordingId)
        kparams.addStringIfDefined("webexHostId", self.webexHostId)
        kparams.addStringIfDefined("description", self.description)
        kparams.addStringIfDefined("confId", self.confId)
        kparams.addStringIfDefined("contentUrl", self.contentUrl)
        return kparams

    def getRecordingId(self):
        return self.recordingId

    def setRecordingId(self, newRecordingId):
        self.recordingId = newRecordingId

    def getWebexHostId(self):
        return self.webexHostId

    def setWebexHostId(self, newWebexHostId):
        self.webexHostId = newWebexHostId

    def getDescription(self):
        return self.description

    def setDescription(self, newDescription):
        self.description = newDescription

    def getConfId(self):
        return self.confId

    def setConfId(self, newConfId):
        self.confId = newConfId

    def getContentUrl(self):
        return self.contentUrl

    def setContentUrl(self, newContentUrl):
        self.contentUrl = newContentUrl


# @package Kaltura
# @subpackage Client
class KalturaWebexDropFolderContentProcessorJobData(KalturaDropFolderContentProcessorJobData):
    def __init__(self,
            dropFolderId=NotImplemented,
            dropFolderFileIds=NotImplemented,
            parsedSlug=NotImplemented,
            contentMatchPolicy=NotImplemented,
            conversionProfileId=NotImplemented,
            parsedUserId=NotImplemented,
            description=NotImplemented,
            webexHostId=NotImplemented):
        KalturaDropFolderContentProcessorJobData.__init__(self,
            dropFolderId,
            dropFolderFileIds,
            parsedSlug,
            contentMatchPolicy,
            conversionProfileId,
            parsedUserId)

        # @var string
        self.description = description

        # @var string
        self.webexHostId = webexHostId


    PROPERTY_LOADERS = {
        'description': getXmlNodeText, 
        'webexHostId': getXmlNodeText, 
    }

    def fromXml(self, node):
        KalturaDropFolderContentProcessorJobData.fromXml(self, node)
        self.fromXmlImpl(node, KalturaWebexDropFolderContentProcessorJobData.PROPERTY_LOADERS)

    def toParams(self):
        kparams = KalturaDropFolderContentProcessorJobData.toParams(self)
        kparams.put("objectType", "KalturaWebexDropFolderContentProcessorJobData")
        kparams.addStringIfDefined("description", self.description)
        kparams.addStringIfDefined("webexHostId", self.webexHostId)
        return kparams

    def getDescription(self):
        return self.description

    def setDescription(self, newDescription):
        self.description = newDescription

    def getWebexHostId(self):
        return self.webexHostId

    def setWebexHostId(self, newWebexHostId):
        self.webexHostId = newWebexHostId


########## services ##########
########## main ##########
class KalturaWebexDropFolderClientPlugin(KalturaClientPlugin):
    # KalturaWebexDropFolderClientPlugin
    instance = None

    # @return KalturaWebexDropFolderClientPlugin
    @staticmethod
    def get():
        if KalturaWebexDropFolderClientPlugin.instance == None:
            KalturaWebexDropFolderClientPlugin.instance = KalturaWebexDropFolderClientPlugin()
        return KalturaWebexDropFolderClientPlugin.instance

    # @return array<KalturaServiceBase>
    def getServices(self):
        return {
        }

    def getEnums(self):
        return {
        }

    def getTypes(self):
        return {
            'KalturaWebexDropFolder': KalturaWebexDropFolder,
            'KalturaWebexDropFolderFile': KalturaWebexDropFolderFile,
            'KalturaWebexDropFolderContentProcessorJobData': KalturaWebexDropFolderContentProcessorJobData,
        }

    # @return string
    def getName(self):
        return 'WebexDropFolder'

