# ===================================================================================================
#                           _  __     _ _
#                          | |/ /__ _| | |_ _  _ _ _ __ _
#                          | ' </ _` | |  _| || | '_/ _` |
#                          |_|\_\__,_|_|\__|\_,_|_| \__,_|
#
# This file is part of the Kaltura Collaborative Media Suite which allows users
# to do with audio, video, and animation what Wiki platfroms allow them to do with
# text.
#
# Copyright (C) 2006-2011  Kaltura Inc.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http:#www.gnu.org/licenses/>.
#
# @ignore
# ===================================================================================================
# @package Kaltura
# @subpackage Client
from Core import *
from CuePoint import *
from ..Base import *

########## enums ##########
########## classes ##########
# @package Kaltura
# @subpackage Client
class KalturaThumbCuePoint(KalturaCuePoint):
    def __init__(self,
            id=NotImplemented,
            cuePointType=NotImplemented,
            status=NotImplemented,
            entryId=NotImplemented,
            partnerId=NotImplemented,
            createdAt=NotImplemented,
            updatedAt=NotImplemented,
            triggeredAt=NotImplemented,
            tags=NotImplemented,
            startTime=NotImplemented,
            userId=NotImplemented,
            partnerData=NotImplemented,
            partnerSortValue=NotImplemented,
            forceStop=NotImplemented,
            thumbOffset=NotImplemented,
            systemName=NotImplemented,
            assetId=NotImplemented,
            description=NotImplemented,
            title=NotImplemented):
        KalturaCuePoint.__init__(self,
            id,
            cuePointType,
            status,
            entryId,
            partnerId,
            createdAt,
            updatedAt,
            triggeredAt,
            tags,
            startTime,
            userId,
            partnerData,
            partnerSortValue,
            forceStop,
            thumbOffset,
            systemName)

        # @var string
        self.assetId = assetId

        # @var string
        self.description = description

        # @var string
        self.title = title


    PROPERTY_LOADERS = {
        'assetId': getXmlNodeText, 
        'description': getXmlNodeText, 
        'title': getXmlNodeText, 
    }

    def fromXml(self, node):
        KalturaCuePoint.fromXml(self, node)
        self.fromXmlImpl(node, KalturaThumbCuePoint.PROPERTY_LOADERS)

    def toParams(self):
        kparams = KalturaCuePoint.toParams(self)
        kparams.put("objectType", "KalturaThumbCuePoint")
        kparams.addStringIfDefined("assetId", self.assetId)
        kparams.addStringIfDefined("description", self.description)
        kparams.addStringIfDefined("title", self.title)
        return kparams

    def getAssetId(self):
        return self.assetId

    def setAssetId(self, newAssetId):
        self.assetId = newAssetId

    def getDescription(self):
        return self.description

    def setDescription(self, newDescription):
        self.description = newDescription

    def getTitle(self):
        return self.title

    def setTitle(self, newTitle):
        self.title = newTitle


# @package Kaltura
# @subpackage Client
class KalturaTimedThumbAsset(KalturaThumbAsset):
    def __init__(self,
            id=NotImplemented,
            entryId=NotImplemented,
            partnerId=NotImplemented,
            version=NotImplemented,
            size=NotImplemented,
            tags=NotImplemented,
            fileExt=NotImplemented,
            createdAt=NotImplemented,
            updatedAt=NotImplemented,
            deletedAt=NotImplemented,
            description=NotImplemented,
            partnerData=NotImplemented,
            partnerDescription=NotImplemented,
            actualSourceAssetParamsIds=NotImplemented,
            thumbParamsId=NotImplemented,
            width=NotImplemented,
            height=NotImplemented,
            status=NotImplemented,
            cuePointId=NotImplemented):
        KalturaThumbAsset.__init__(self,
            id,
            entryId,
            partnerId,
            version,
            size,
            tags,
            fileExt,
            createdAt,
            updatedAt,
            deletedAt,
            description,
            partnerData,
            partnerDescription,
            actualSourceAssetParamsIds,
            thumbParamsId,
            width,
            height,
            status)

        # Associated thumb cue point ID
        # @var string
        # @insertonly
        self.cuePointId = cuePointId


    PROPERTY_LOADERS = {
        'cuePointId': getXmlNodeText, 
    }

    def fromXml(self, node):
        KalturaThumbAsset.fromXml(self, node)
        self.fromXmlImpl(node, KalturaTimedThumbAsset.PROPERTY_LOADERS)

    def toParams(self):
        kparams = KalturaThumbAsset.toParams(self)
        kparams.put("objectType", "KalturaTimedThumbAsset")
        kparams.addStringIfDefined("cuePointId", self.cuePointId)
        return kparams

    def getCuePointId(self):
        return self.cuePointId

    def setCuePointId(self, newCuePointId):
        self.cuePointId = newCuePointId


########## services ##########
########## main ##########
class KalturaThumbCuePointClientPlugin(KalturaClientPlugin):
    # KalturaThumbCuePointClientPlugin
    instance = None

    # @return KalturaThumbCuePointClientPlugin
    @staticmethod
    def get():
        if KalturaThumbCuePointClientPlugin.instance == None:
            KalturaThumbCuePointClientPlugin.instance = KalturaThumbCuePointClientPlugin()
        return KalturaThumbCuePointClientPlugin.instance

    # @return array<KalturaServiceBase>
    def getServices(self):
        return {
        }

    def getEnums(self):
        return {
        }

    def getTypes(self):
        return {
            'KalturaThumbCuePoint': KalturaThumbCuePoint,
            'KalturaTimedThumbAsset': KalturaTimedThumbAsset,
        }

    # @return string
    def getName(self):
        return 'thumbCuePoint'

